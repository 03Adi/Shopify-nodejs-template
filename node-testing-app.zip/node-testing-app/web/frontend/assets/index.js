export { default as notFoundImage } from "./empty-state.svg";
export { default as trophyImage } from "./home-trophy.png";
